// Dark Mode Toggle
const themeToggle = document.getElementById('themeToggle');
const body = document.body;

const textElement = document.getElementById("typing-text");
const phrases = ["Web Developer", "UI Designer", "Student"];
let phraseIndex = 0;
let charIndex = 0;
let isDeleting = false;
let typeSpeed = 150;

function openProject(card) {
    const url = card.getAttribute("data-url");
    if (url) {
        window.location.href = url;
    }

}
function type() {
    const currentPhrase = phrases[phraseIndex];

    if (isDeleting) {
        // Binubura ang text
        textElement.textContent = currentPhrase.substring(0, charIndex - 1);
        charIndex--;
        typeSpeed = 50; // Mas mabilis kapag nagbubura
    } else {
        // Sinusulat ang text
        textElement.textContent = currentPhrase.substring(0, charIndex + 1);
        charIndex++;
        typeSpeed = 150; // Normal speed kapag nagsusulat
    }

    // Logic para sa paglipat ng phrase
    if (!isDeleting && charIndex === currentPhrase.length) {
        isDeleting = true;
        typeSpeed = 2000; // Pause sa dulo bago burahin
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
        typeSpeed = 500; // Konting pause bago magsimula ulit
    }

    setTimeout(type, typeSpeed);
}

// Simulan ang typing effect pagka-load ng page
document.addEventListener("DOMContentLoaded", type);

themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    if (body.classList.contains('dark-mode')) {
        themeToggle.textContent = '☀️ Light Mode';
    } else {
        themeToggle.textContent = '🌙 Dark Mode';
    }
});

// Smooth Scrolling for Navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Basic Form Submission Alert
document.getElementById('contactForm').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thank you, John Paul will get back to you soon!');
    e.target.reset();
});